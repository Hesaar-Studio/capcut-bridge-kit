# پل ارتباطی HS.Tech (Hesa Art Tech Video Bridge)
> **Package / Repository:** `hs-art-tech-bridge` | **Version:** `2.4.0`  
> High-Performance Multi-NLE Integration: **CapCut Desktop**, **Adobe Premiere Pro**, and **DaVinci Resolve**.

---

## 🇮🇷 راهنمای فارسی (Persian Documentation)

### درباره پروژه
«پل ارتباطی HS.Tech» (مخفف هسا آرت تک / Hesa Art Tech) یک زیرساخت مدرن جهت اتصال سامانه‌های هوش مصنوعی (مانند کلود، چت‌جی‌پی‌تی، کورسر و کدکس) به نرم‌افزارهای تدوین ویدیوی استاندارد صنعت می‌باشد:
1. **کپکات دسکتاپ (CapCut Desktop):** تولید مستقیم `draft_content.json` با رفع باگ اتصال و اصلاح خودکار متون فارسی راست‌به‌چپ (RTL).
2. **ادوبی پرمیر پرو (Adobe Premiere Pro):** صدور فایل ساختار جدول زمانی Apple FCPXML 1.10 به همراه مارکرها و زیرنویس‌ها.
3. **داوینچی ریزالو (DaVinci Resolve):** صدور لیست برش‌های CMX3600 EDL و استخراج جدول رنگ سه‌بعدی `3D CUBE LUT` (33x33x33).

### روش‌های استقرار و اجرا

#### روش اول: اجرای دسکتاپ و System Tray (فایل اجرایی ویندوز)
1. فایل `setup.bat` را اجرا کنید تا پیش‌نیازها به طور خودکار نصب شوند.
2. با دستور `npm start` در این پوشه، برنامه دسکتاپ در کنار ساعت ویندوز (Tray) فعال شده و پورت محلی `8765` را مدیریت می‌کند.
3. برای کامپایل فایل نصبی `.exe` اختصاصی ویندوز، دستور زیر را اجرا کنید:
   ```bash
   npm run build:win
   ```
   فایل نصبی نهایی در مسیر `dist/HS.Tech Video Bridge Setup.exe` آماده خواهد شد.

#### روش دوم: پروتکل Model Context Protocol (MCP) برای دستیارهای هوش مصنوعی
برای استفاده در **Claude Desktop**:
محتوای فایل `claude_desktop_config.json` را به فایل کانفیگ کلود در مسیر زیر اضافه کنید:
* **ویندوز:** `%APPDATA%\Claude\claude_desktop_config.json`
* **مک:** `~/Library/Application Support/Claude/claude_desktop_config.json`

ابزارهای در دسترس هوش مصنوعی:
* `sync_timeline_to_nle`: همگام‌سازی برش‌ها و متون با نرم‌افزار تدوین
* `export_color_grade_lut`: صدور فایل رنگ ۳۳×۳۳×۳۳ برای پرمیر و داوینچی
* `check_nle_bridge_status`: گزارش سلامت و وضعیت نرم‌افزارهای متصل

---

## 🇬🇧 English Documentation

### Overview
**HS.Tech Video Bridge** (short for Hesa Art Tech) is a professional multi-NLE bridge bridging AI systems (Claude, ChatGPT, Cursor, Codex, and local LLMs) with industry-standard editing software:
* **CapCut Desktop**: Native JSON draft conform with Persian RTL text shaping and timerange bugfixes.
* **Adobe Premiere Pro**: Apple FCPXML 1.10 sequence and timeline export.
* **DaVinci Resolve**: CMX3600 EDL cut lists and 33x33x33 3D CUBE LUT export.

### Installation & Deployment

#### 1. Windows 1-Click Setup & Desktop Daemon
Run `setup.bat` on Windows or `install.sh` on macOS/Linux.
Launch the system tray daemon:
```bash
npm install
npm start
```
To build standalone Windows NSIS `.exe` installer:
```bash
npm run build:win
```

#### 2. Model Context Protocol (MCP)
Register `hs-art-tech-bridge` in your Claude Desktop configuration:
```json
{
  "mcpServers": {
    "hs-art-tech-bridge": {
      "command": "python",
      "args": ["/path/to/bridge_server.py", "--mcp"]
    }
  }
}
```

### Endpoints (Port 8765)
* `GET /health` - Health check & connected NLE detection
* `POST /api/v1/sync` - Sync cuts, subtitles, and markers
* `POST /api/v1/export-lut` - Generate and download 3D CUBE LUT
