// Electron Tray Daemon for HS.Tech Video Bridge (Hesa Art Tech)
const { app, Tray, Menu, shell, dialog, nativeImage } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const http = require('http');

let tray = null;
let pythonProcess = null;

const PORT = 8765;
const STUDIO_URL = 'http://localhost:3000';

function spawnPythonBridge() {
  const pythonExecutable = process.platform === 'win32' ? 'python' : 'python3';
  const serverScript = path.join(__dirname, 'bridge_server.py');

  try {
    pythonProcess = spawn(pythonExecutable, [serverScript, '--port', `${PORT}`], {
      detached: false,
      stdio: 'pipe'
    });

    pythonProcess.stdout.on('data', (data) => {
      console.log(`[Bridge Server]: ${data}`);
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error(`[Bridge Server Error]: ${data}`);
    });

    pythonProcess.on('close', (code) => {
      console.log(`Bridge server stopped with code ${code}`);
    });
  } catch (err) {
    console.error('Failed to spawn Python bridge server:', err);
  }
}

function checkServerHealth(callback) {
  const req = http.get(`http://127.0.0.1:${PORT}/health`, (res) => {
    let raw = '';
    res.on('data', (chunk) => (raw += chunk));
    res.on('end', () => {
      try {
        const json = JSON.parse(raw);
        callback(true, json);
      } catch (e) {
        callback(true, { status: 'online' });
      }
    });
  });

  req.on('error', () => {
    callback(false, null);
  });
  req.setTimeout(1500, () => {
    req.abort();
    callback(false, null);
  });
}

function createTray() {
  // 16x16 or 32x32 transparent icon fallback
  const icon = nativeImage.createEmpty();
  tray = new Tray(icon);
  tray.setToolTip('HS.Tech Video Bridge (CapCut · Premiere · DaVinci)');

  updateContextMenu(true);
}

function updateContextMenu(isOnline) {
  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'HS.Tech Video Bridge (Hesa Art Tech)',
      enabled: false
    },
    {
      label: `Status: ${isOnline ? 'Online (Port 8765)' : 'Connecting...'}`,
      icon: null,
      enabled: false
    },
    { type: 'separator' },
    {
      label: 'Open Web Studio',
      click: () => shell.openExternal(STUDIO_URL)
    },
    {
      label: 'Check NLE Connection Health',
      click: () => {
        checkServerHealth((ok, info) => {
          if (ok) {
            dialog.showMessageBox({
              type: 'info',
              title: 'HS.Tech Bridge Status',
              message: 'Bridge server is healthy and listening on port 8765.',
              detail: JSON.stringify(info || {}, null, 2)
            });
          } else {
            dialog.showErrorBox(
              'Bridge Offline',
              'Could not connect to Python bridge server on port 8765. Make sure Python 3 is installed.'
            );
          }
        });
      }
    },
    {
      label: 'View Claude MCP Config',
      click: () => {
        const configPath = path.join(__dirname, 'claude_desktop_config.json');
        shell.showItemInFolder(configPath);
      }
    },
    { type: 'separator' },
    {
      label: 'Restart Python Daemon',
      click: () => {
        if (pythonProcess) pythonProcess.kill();
        spawnPythonBridge();
      }
    },
    {
      label: 'Quit',
      click: () => {
        if (pythonProcess) pythonProcess.kill();
        app.quit();
      }
    }
  ]);

  tray.setContextMenu(contextMenu);
}

app.whenReady().then(() => {
  spawnPythonBridge();
  createTray();
  setInterval(() => {
    checkServerHealth((ok) => updateContextMenu(ok));
  }, 10000);
});

app.on('window-all-closed', (e) => {
  e.preventDefault(); // Keep daemon in system tray
});

app.on('will-quit', () => {
  if (pythonProcess) {
    try {
      pythonProcess.kill();
    } catch (e) {}
  }
});
