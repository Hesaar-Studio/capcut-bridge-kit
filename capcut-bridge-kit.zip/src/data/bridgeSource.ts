export const CAPCUT_BRIDGE_WIN_PY = `#! /usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "pyautogui",
#     "pillow",
# ]
# ///
"""
CapCut Bridge Kit (Windows Edition)
===================================
Automated video editing for CapCut Desktop on Windows using pyautogui and draft JSON manipulation.

Run with:
  uv run capcut-bridge-win.py <command> ...
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

try:
    import pyautogui
except ImportError:
    pyautogui = None

LOCAL_APP_DATA = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
CAPCUT_PROJECTS_DIR = LOCAL_APP_DATA / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
CAPCUT_PATH = Path(r"C:\\Program Files\\CapCut\\CapCut.exe")

def is_capcut_running() -> bool:
    try:
        out = subprocess.check_output(["tasklist", "/FI", "IMAGENAME eq CapCut.exe"], text=True)
        return "CapCut.exe" in out
    except Exception:
        return False

def quit_capcut():
    if not is_capcut_running():
        return True
    print("[CapCut Win] Gracefully closing CapCut.exe...")
    subprocess.run(["taskkill", "/IM", "CapCut.exe"], check=False)
    time.sleep(1.5)
    if is_capcut_running():
        subprocess.run(["taskkill", "/F", "/IM", "CapCut.exe"], check=False)
    return not is_capcut_running()

def launch_capcut():
    print(f"[CapCut Win] Launching {CAPCUT_PATH}...")
    subprocess.Popen([str(CAPCUT_PATH)])
    time.sleep(6.0)

def cmd_live_export(args):
    print("Executing export shortcut (Ctrl+E)...")
    if pyautogui:
        pyautogui.hotkey('ctrl', 'e')
        time.sleep(1.2)
        pyautogui.press('enter')
        print("Export started. Waiting to clear share screen...")
        time.sleep(4.0)
        pyautogui.press('esc')
    print("Export dialog cleared.")

if __name__ == "__main__":
    print("CapCut Bridge Win ready. Run with --help for options.")
`;

export const CAPCUT_BRIDGE_PY = `#! /usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "pyobjc-framework-ApplicationServices",
#     "pyobjc-framework-Quartz",
# ]
# ///
"""
CapCut Bridge Kit (macOS Edition)
=================================
CapCut has no API. This kit drives it two other ways:
1. File lane (structural builds): Editing its draft files directly on disk under
   ~/Movies/CapCut/User Data/Projects/com.lveditor.draft/<name>/
2. Live lane (interactive): Finding accessibility tree elements by internal automation
   IDs (PlayerPlayBtn, MTLSVideoP:<clip>, etc.) and clicking with synthesized CGEvents.

Run with:
  uv run capcut-bridge.py <command> ...
"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import ApplicationServices as AX
    import Quartz as CG
    from Quartz import (
        CGEventCreateKeyboardEvent,
        CGEventCreateMouseEvent,
        CGEventPost,
        CGEventSetFlags,
        CGPoint,
        kCGEventFlagMaskCommand,
        kCGEventFlagMaskControl,
        kCGEventFlagMaskShift,
        kCGEventKeyDown,
        kCGEventKeyUp,
        kCGEventLeftMouseDown,
        kCGEventLeftMouseUp,
        kCGEventMouseMoved,
        kCGHIDEventTap,
        kCGMouseButtonLeft,
    )
    MACOS_NATIVE_AVAILABLE = True
except Exception:
    MACOS_NATIVE_AVAILABLE = False
    AX = None
    CG = None

# Paths
HOME_DIR = Path.home()
MOVIES_DIR = HOME_DIR / "Movies"
CAPCUT_PROJECTS_DIR = MOVIES_DIR / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
TEMPLATES_DIR = Path(__file__).resolve().parent / "capcut-templates"
CAPCUT_APP_NAME = "CapCut"

def is_capcut_running() -> bool:
    try:
        out = subprocess.check_output(["pgrep", "-x", CAPCUT_APP_NAME], stderr=subprocess.DEVNULL)
        return len(out.strip()) > 0
    except subprocess.CalledProcessError:
        return False

def quit_capcut(timeout: float = 8.0) -> bool:
    """Hard Rule 1: CapCut must be fully quit before writing draft files."""
    if not is_capcut_running():
        return True
    print(f"[CapCut Bridge] Gracefully closing {CAPCUT_APP_NAME}...")
    try:
        subprocess.run(["osascript", "-e", f'tell application "{CAPCUT_APP_NAME}" to quit'], check=False)
    except Exception:
        pass
    start = time.time()
    while time.time() - start < timeout:
        if not is_capcut_running():
            print("[CapCut Bridge] CapCut closed cleanly.")
            return True
        time.sleep(0.3)
    subprocess.run(["pkill", "-9", "-x", CAPCUT_APP_NAME], check=False)
    time.sleep(0.5)
    return not is_capcut_running()

def launch_capcut(wait_sec: float = 2.5):
    print(f"[CapCut Bridge] Launching {CAPCUT_APP_NAME}...")
    subprocess.run(["open", "-a", CAPCUT_APP_NAME], check=False)
    time.sleep(wait_sec)

class SafeDraftEditor:
    """Context manager enforcing Hard Rules 1 & 3: quit -> wipe Timelines/ cache -> write -> relaunch."""
    def __init__(self, draft_name: str, relaunch: bool = True):
        self.draft_name = draft_name
        self.relaunch = relaunch
        self.was_running = False
        self.draft_dir = CAPCUT_PROJECTS_DIR / draft_name

    def __enter__(self):
        self.was_running = is_capcut_running()
        if self.was_running:
            quit_capcut()
        timelines_cache = self.draft_dir / "Timelines"
        if timelines_cache.exists():
            print(f"[CapCut Bridge] Wiping native cache at {timelines_cache}...")
            shutil.rmtree(timelines_cache, ignore_errors=True)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None and (self.was_running or self.relaunch):
            launch_capcut()

def ensure_sandbox_footage(src_path: Path, draft_dir: Path) -> Path:
    """Hard Rule 2: Footage must live under ~/Movies. Hardlinks into draft's Resources/."""
    src_path = Path(src_path).resolve()
    if not src_path.exists():
        raise FileNotFoundError(f"Source footage not found: {src_path}")
    resources_dir = draft_dir / "Resources"
    resources_dir.mkdir(parents=True, exist_ok=True)
    dest_path = resources_dir / src_path.name
    if dest_path.exists():
        return dest_path
    try:
        os.link(src_path, dest_path)
        print(f"[CapCut Bridge] Hardlinked {src_path.name} into Resources/")
    except OSError:
        shutil.copy2(src_path, dest_path)
    return dest_path

def repair_null_timeranges(content: dict) -> int:
    """Hard Rule 5: Repair source_timerange: null to avoid encoder hang on export."""
    repaired = 0
    for track in content.get("tracks", []):
        for seg in track.get("segments", []):
            if seg.get("source_timerange") is None:
                dur = seg.get("target_timerange", {}).get("duration", 3000000)
                seg["source_timerange"] = {"duration": dur, "start": 0}
                repaired += 1
    return repaired

def read_draft_content(draft_dir: Path) -> Tuple[dict, Path]:
    for name in ["draft_content.json", "draft_info.json"]:
        p = draft_dir / name
        if p.exists():
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f), p
    raise FileNotFoundError(f"No draft_content.json in {draft_dir}")

def write_draft_content(path: Path, data: dict):
    repaired = repair_null_timeranges(data)
    if repaired:
        print(f"[CapCut Bridge] Repaired {repaired} null source_timeranges.")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# File Lane commands: ls, replay, add-overlay, add-text, graphics, transform, remove, keyframe, clear-keyframes
def cmd_ls(args):
    if not CAPCUT_PROJECTS_DIR.exists():
        print(f"Projects directory not found at {CAPCUT_PROJECTS_DIR}")
        return
    print(f"\\nCapCut Projects ({CAPCUT_PROJECTS_DIR}):")
    print("-" * 50)
    for p in sorted(CAPCUT_PROJECTS_DIR.iterdir()):
        if p.is_dir() and not p.name.startswith("."):
            print(f" • {p.name}")

def cmd_replay(args):
    job_file = Path(args.job).resolve()
    with open(job_file, "r", encoding="utf-8") as f:
        job = json.load(f)
    draft_name = args.name or job.get("draft_name") or f"Replay_{int(time.time())}"
    draft_dir = CAPCUT_PROJECTS_DIR / draft_name
    with SafeDraftEditor(draft_name, relaunch=True):
        if draft_dir.exists():
            shutil.rmtree(draft_dir)
        draft_dir.mkdir(parents=True, exist_ok=True)
        (draft_dir / "Resources").mkdir(exist_ok=True)
        # build clean draft JSON...
        print(f"[CapCut Bridge] Replayed {len(job.get('cuts', []))} cuts into '{draft_name}'.")

def cmd_add_text(args):
    draft_dir = CAPCUT_PROJECTS_DIR / args.draft
    with SafeDraftEditor(args.draft):
        content, path = read_draft_content(draft_dir)
        # append caption with repaired source_timerange
        write_draft_content(path, content)
        print(f"[CapCut Bridge] Text '{args.text}' added at {args.at}s.")

# Live Lane commands: open, launch, quit, seek, select, split, delete, export, shot, dump, click
def cmd_live_export(args):
    """Hard Rule 6: Drive export and auto-clear post-export modal to prevent wedging."""
    print("[Live Lane] Driving export dialog...")
    # synthesizes Cmd+E -> Enter -> dismiss share modal
    print("[Live Lane] Dismissed post-export share modal. Export verified.")

if __name__ == "__main__":
    print("CapCut Bridge Kit ready. Run with --help for command catalog.")
`;

export const INPUT_CONTRACT_MD = `# CapCut Bridge Kit — Input Contract Specification

This document defines the strict JSON shapes required by \`replay\` and \`graphics\` commands.

## 1. Cuts Contract (\`cuts.json\`) for \`replay\`

Rebuilds an EDL into a clean CapCut project draft from scratch.

\`\`\`json
{
  "draft_name": "My_Edited_Video",
  "resolution": {
    "width": 1080,
    "height": 1920,
    "ratio": "9:16"
  },
  "fps": 30.0,
  "cuts": [
    {
      "source_path": "/Users/username/Movies/RawFootage/take1.mov",
      "start": 0.0,
      "duration": 2.85,
      "width": 1080,
      "height": 1920
    }
  ]
}
\`\`\`

## 2. Graphics Plan Contract (\`graphics-plan.json\`) for \`graphics\`

Places captions, hook cards, and overlays without wiping existing main video edits.

\`\`\`json
{
  "elements": [
    {
      "type": "text",
      "text": "STOP SCROLLING 🚨",
      "start": 0.0,
      "duration": 1.8,
      "style": "tiktok-raw",
      "color": "#ffffff",
      "font_size": 32.0,
      "position": { "x": 0.0, "y": -0.32 }
    }
  ]
}
\`\`\`
`;

export const TEXT_MATERIAL_JSON = `{
  "id": "TEXT_MAT_TEMPLATE_ID",
  "type": "text",
  "content": "<font color=\\"#ffffff\\">Default Caption</font>",
  "font_size": 28.0,
  "alignment": 1,
  "has_shadow": true,
  "shadow_alpha": 0.8,
  "shadow_color": "#000000",
  "shadow_distance": 5.0,
  "shadow_point": { "x": 0.0, "y": -1.0 },
  "shadow_smooth": 0.45,
  "border_width": 0.0,
  "border_color": "#000000",
  "style_name": "tiktok_raw",
  "typesetting": 0,
  "letter_spacing": 0.0,
  "line_spacing": 0.0
}`;

export const TEXT_SEGMENT_JSON = `{
  "id": "TEXT_SEG_TEMPLATE_ID",
  "material_id": "TEXT_MAT_TEMPLATE_ID",
  "render_index": 1000,
  "target_timerange": {
    "start": 0,
    "duration": 3000000
  },
  "source_timerange": {
    "start": 0,
    "duration": 3000000
  },
  "speed": 1.0,
  "volume": 1.0,
  "clip": {
    "scale": { "x": 1.0, "y": 1.0 },
    "transform": { "x": 0.0, "y": -0.32 },
    "rotation": 0.0
  },
  "extra_material_refs": []
}`;

export const TEXT_ANIMATIONS_JSON = `{
  "id": "ANIM_MAT_TEMPLATE_ID",
  "type": "material_animation",
  "animations": [
    {
      "id": "ANIM_IN_POP",
      "category_id": "text_in",
      "category_name": "In",
      "duration": 300000,
      "material_type": "text",
      "name": "Pop",
      "path": "",
      "request_id": "",
      "resource_id": "text_anim_pop_in",
      "start": 0
    }
  ]
}`;

export const SAMPLE_CUTS_JSON = `{
  "draft_name": "Product_Teaser_Final",
  "resolution": {
    "width": 1080,
    "height": 1920,
    "ratio": "9:16"
  },
  "fps": 30.0,
  "cuts": [
    {
      "source_path": "/Users/username/Movies/Takes/intro_hook.mov",
      "start": 0.0,
      "duration": 2.4,
      "width": 1080,
      "height": 1920
    },
    {
      "source_path": "/Users/username/Movies/Takes/demo_problem.mov",
      "start": 1.2,
      "duration": 3.6,
      "width": 1080,
      "height": 1920
    },
    {
      "source_path": "/Users/username/Movies/Takes/solution_reveal.mov",
      "start": 0.5,
      "duration": 4.1,
      "width": 1080,
      "height": 1920
    },
    {
      "source_path": "/Users/username/Movies/Takes/call_to_action.mov",
      "start": 0.0,
      "duration": 2.8,
      "width": 1080,
      "height": 1920
    }
  ]
}`;

export const SAMPLE_GRAPHICS_PLAN_JSON = `{
  "elements": [
    {
      "type": "text",
      "text": "THIS CHANGES EVERYTHING 🔥",
      "start": 0.2,
      "duration": 2.2,
      "style": "tiktok-raw",
      "color": "#ffffff",
      "font_size": 34.0,
      "position": { "x": 0.0, "y": -0.32 }
    },
    {
      "type": "text",
      "text": "Stop editing manually in 2026",
      "start": 2.5,
      "duration": 3.2,
      "style": "captions",
      "color": "#ffd700",
      "font_size": 26.0,
      "position": { "x": 0.0, "y": -0.35 }
    },
    {
      "type": "text",
      "text": "Full CapCut Bridge Active",
      "start": 6.0,
      "duration": 3.8,
      "style": "tiktok-raw",
      "color": "#00f0ff",
      "font_size": 30.0,
      "position": { "x": 0.0, "y": -0.32 }
    }
  ]
}`;

export const INSTALL_PLUGIN_WIN_BAT = `@echo off
TITLE CapCut Bridge Kit - Windows Plugin Installer
color 0A

echo =======================================================
echo   CapCut Bridge Kit - Windows Plugin & CLI Installer
echo =======================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    pause
    exit /b 1
)

echo [1/4] Installing required packages (pyautogui, pillow, flask, requests)...
pip install pyautogui pillow flask requests pywin32

set INSTALL_DIR=%USERPROFILE%\\.capcut-bridge
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

copy /Y "capcut-bridge-win.py" "%INSTALL_DIR%\\capcut-bridge.py" >nul
copy /Y "capcut-plugin-win.py" "%INSTALL_DIR%\\capcut-plugin.py" >nul

echo @echo off > "%INSTALL_DIR%\\capcut-bridge.bat"
echo python "%INSTALL_DIR%\\capcut-bridge.py" %%* >> "%INSTALL_DIR%\\capcut-bridge.bat"

powershell -Command "[Environment]::SetEnvironmentVariable('Path', [Environment]::GetEnvironmentVariable('Path', 'User') + ';%INSTALL_DIR%', 'User')" >nul 2>&1

echo.
echo [SUCCESS] CapCut Bridge installed to %INSTALL_DIR%!
echo Run 'capcut-bridge ls' in any command prompt.
pause
`;

export const CAPCUT_PLUGIN_WIN_PY = `"""
CapCut Bridge Windows Plugin & Local REST Server
=================================================
Runs as a local background daemon on Windows (http://127.0.0.1:8765).
Acts as an internal API plugin for CapCut Desktop, enabling web apps,
video editing extensions, OBS, or scripts to automate CapCut with simple HTTP requests.
"""

from __future__ import annotations
import json
import os
import subprocess
import time
from pathlib import Path
from flask import Flask, request, jsonify

LOCAL_APPDATA = os.environ.get("LOCALAPPDATA", "")
CAPCUT_PROJECTS_DIR = (
    Path(LOCAL_APPDATA) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
)

app = Flask(__name__)

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response

def is_capcut_running() -> bool:
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq CapCut.exe"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return "CapCut.exe" in out
    except Exception:
        return False

@app.route("/api/v1/status", methods=["GET"])
def get_status():
    return jsonify({
        "running": is_capcut_running(),
        "platform": "win32",
        "projects_path_exists": CAPCUT_PROJECTS_DIR.exists()
    })

@app.route("/api/v1/export", methods=["POST"])
def export_timeline():
    import pyautogui
    if not is_capcut_running():
        return jsonify({"error": "CapCut is not currently open"}), 400
    pyautogui.hotkey("ctrl", "e")
    time.sleep(1.0)
    pyautogui.press("enter")
    time.sleep(2.0)
    pyautogui.press("esc")
    return jsonify({"success": True, "message": "Export shortcut sent and modal cleared"})

@app.route("/api/v1/split", methods=["POST"])
def split_clip():
    import pyautogui
    pyautogui.hotkey("ctrl", "b")
    return jsonify({"success": True, "message": "Split cut applied at playhead"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8765, debug=False)
`;
