import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { CommandBuilder } from './components/CommandBuilder';
import { TimelineVisualizer } from './components/TimelineVisualizer';
import { CodeViewer } from './components/CodeViewer';
import { RulesValidator } from './components/RulesValidator';
import { InputContractEditor } from './components/InputContractEditor';
import { WindowsPluginGuide } from './components/WindowsPluginGuide';
import { CapCutStudio } from './components/CapCutStudio';
import { PromptLibrary } from './components/PromptLibrary';
import { EditingMastery } from './components/EditingMastery';
import {
  CAPCUT_BRIDGE_PY,
  CAPCUT_BRIDGE_WIN_PY,
  INSTALL_PLUGIN_WIN_BAT,
  CAPCUT_PLUGIN_WIN_PY,
} from './data/bridgeSource';
import { Platform } from './types';
import { EditingPrompt } from './data/editingPrompts';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('studio');
  const [platform, setPlatform] = useState<Platform>('win');

  const handleDownloadPy = () => {
    const isWin = platform === 'win';
    const content = isWin ? CAPCUT_BRIDGE_WIN_PY : CAPCUT_BRIDGE_PY;
    const filename = isWin ? 'capcut-bridge-win.py' : 'capcut-bridge.py';

    const blob = new Blob([content], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadFile = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black">
      {/* Top Bar following Top Bar Contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        platform={platform}
        setPlatform={setPlatform}
        onDownloadPy={handleDownloadPy}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-2 sm:p-4 lg:p-5">
        {activeTab === 'studio' && <CapCutStudio platform={platform} />}
        {activeTab === 'prompts' && (
          <PromptLibrary 
            platform={platform} 
            onInjectPrompt={(_p) => {
              setActiveTab('studio');
            }}
          />
        )}
        {activeTab === 'mastery' && (
          <EditingMastery 
            platform={platform} 
            onNavigateToTab={(tab) => setActiveTab(tab)} 
          />
        )}
        {activeTab === 'commands' && <CommandBuilder platform={platform} />}
        {activeTab === 'timeline' && <TimelineVisualizer />}
        {activeTab === 'plugin' && (
          <WindowsPluginGuide
            onDownloadWinScript={() => handleDownloadFile(CAPCUT_BRIDGE_WIN_PY, 'capcut-bridge-win.py', 'text/x-python;charset=utf-8')}
            onDownloadInstaller={() => handleDownloadFile(INSTALL_PLUGIN_WIN_BAT, 'install-plugin-win.bat', 'application/x-bat')}
            onDownloadPluginDaemon={() => handleDownloadFile(CAPCUT_PLUGIN_WIN_PY, 'capcut-plugin-win.py', 'text/x-python;charset=utf-8')}
          />
        )}
        {activeTab === 'code' && <CodeViewer />}
        {activeTab === 'contracts' && <InputContractEditor />}
        {activeTab === 'rules' && <RulesValidator />}
      </main>

      {/* Quiet single-elevation status footer */}
      <footer className="border-t border-neutral-800 bg-neutral-950/80 px-6 py-4 text-xs text-neutral-500 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-neutral-300 font-medium">CapCut Bridge Kit</span>
          <span>·</span>
          <span>macOS Desktop Automation</span>
          <span>·</span>
          <span className="font-mono text-emerald-400">PEP 723 uv Compatible</span>
        </div>
        <div className="flex items-center gap-4 text-neutral-400">
          <span>File Lane: ~/Movies/CapCut Projects</span>
          <span>·</span>
          <span>Live Lane: PyObjC / Quartz</span>
        </div>
      </footer>
    </div>
  );
}
