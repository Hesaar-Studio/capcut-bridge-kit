"""
CapCut Bridge Windows Plugin & Local REST Server
=================================================
Runs as a local background daemon on Windows (http://127.0.0.1:8765).
Acts as an internal API plugin for CapCut Desktop, enabling web apps,
video editing extensions, OBS, or scripts to automate CapCut with simple HTTP requests.

Install and run:
    pip install flask pyautogui pillow
    python capcut-plugin-win.py
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from flask import Flask, request, jsonify

# Windows CapCut Paths
LOCAL_APPDATA = os.environ.get("LOCALAPPDATA", "")
CAPCUT_PROJECTS_DIR = (
    Path(LOCAL_APPDATA) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
)

app = Flask(__name__)

# Enable CORS for local web tools
@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response


def is_capcut_running() -> bool:
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq CapCut.exe"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return "CapCut.exe" in out
    except Exception:
        return False


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "plugin": "CapCut Bridge Windows Plugin",
        "version": "1.2.0",
        "platform": "Windows",
        "capcut_running": is_capcut_running(),
        "projects_dir": str(CAPCUT_PROJECTS_DIR),
        "endpoints": [
            "GET /api/v1/status",
            "GET /api/v1/drafts",
            "POST /api/v1/launch",
            "POST /api/v1/export",
            "POST /api/v1/split",
            "POST /api/v1/play",
            "POST /api/v1/seek",
            "POST /api/v1/add-text",
            "POST /api/v1/replay"
        ]
    })


@app.route("/api/v1/status", methods=["GET"])
def get_status():
    running = is_capcut_running()
    return jsonify({
        "running": running,
        "platform": "win32",
        "projects_path_exists": CAPCUT_PROJECTS_DIR.exists()
    })


@app.route("/api/v1/drafts", methods=["GET"])
def list_drafts():
    if not CAPCUT_PROJECTS_DIR.exists():
        return jsonify({"drafts": [], "error": "Projects directory not found"}), 404

    drafts = []
    for item in sorted(CAPCUT_PROJECTS_DIR.iterdir()):
        if item.is_dir() and not item.name.startswith("."):
            content_file = item / "draft_content.json"
            dur_sec = 0.0
            if content_file.exists():
                try:
                    with open(content_file, "r", encoding="utf-8") as f:
                        d = json.load(f)
                        dur_sec = d.get("duration", 0) / 1_000_000
                except Exception:
                    pass
            drafts.append({
                "name": item.name,
                "duration_seconds": dur_sec,
                "path": str(item)
            })

    return jsonify({"drafts": drafts, "count": len(drafts)})


@app.route("/api/v1/export", methods=["POST"])
def export_timeline():
    """Trigger Export dialog and clear modal share screen using pyautogui."""
    try:
        import pyautogui
    except ImportError:
        return jsonify({"error": "pyautogui is required for Live actions. Run: pip install pyautogui"}), 500

    if not is_capcut_running():
        return jsonify({"error": "CapCut is not currently open"}), 400

    # Ctrl + E shortcut
    pyautogui.hotkey("ctrl", "e")
    time.sleep(1.0)
    # Confirm
    pyautogui.press("enter")
    time.sleep(2.0)
    # Clear modal share screen (Esc)
    pyautogui.press("esc")

    return jsonify({"success": True, "message": "Export shortcut sent and post-export modal cleared"})


@app.route("/api/v1/split", methods=["POST"])
def split_clip():
    """Trigger Split cut (Ctrl+B) at current playhead."""
    try:
        import pyautogui
    except ImportError:
        return jsonify({"error": "pyautogui required"}), 500

    pyautogui.hotkey("ctrl", "b")
    return jsonify({"success": True, "message": "Split cut applied at playhead"})


@app.route("/api/v1/play", methods=["POST"])
def toggle_play():
    """Toggle Play / Pause (Space)."""
    try:
        import pyautogui
    except ImportError:
        return jsonify({"error": "pyautogui required"}), 500

    pyautogui.press("space")
    return jsonify({"success": True, "message": "Play/Pause toggled"})


if __name__ == "__main__":
    port = int(os.environ.get("CAPCUT_PLUGIN_PORT", 8765))
    print(f"=======================================================")
    print(f"  CapCut Windows Plugin Server running on port {port}")
    print(f"  API Address: http://127.0.0.1:{port}")
    print(f"=======================================================")
    app.run(host="127.0.0.1", port=port, debug=False)
